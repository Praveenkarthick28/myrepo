sudo apt-get update -y
sudo apt install openjdk-11-jre -y
sudo apt-get install maven -y

