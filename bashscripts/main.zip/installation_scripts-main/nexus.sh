# UBUNTU Installation for java 11 as default

sudo apt update
java -version
sudo apt install default-jre
sudo apt --fix-broken install
