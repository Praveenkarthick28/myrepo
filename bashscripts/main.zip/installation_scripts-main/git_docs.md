### How to rewrite/delete commits from the Repository? 
```
git reset --soft HEAD~N (N indicates the number of commits to be removed) Further removes it from local repository
git push origin +main --force
```
