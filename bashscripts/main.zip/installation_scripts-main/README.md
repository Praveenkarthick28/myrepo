# tools_installations_scripts
It contains the commands to install various tools in the pipelines

